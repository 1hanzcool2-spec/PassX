import tkinter as tk
from tkinter import messagebox, filedialog
import os

class PassXApp:
    def __init__(self, root):
        self.root = root
        self.root.title("PassX Password Manager")
        self.root.geometry("500x600")
        self.root.configure(bg="#667eea")                                                                                                                                                       

        self.entries = []

        # Title
        self.title_label = tk.Label(root, text="PassX Passwort-Manager", font=("Arial", 20, "bold"), bg="#667eea", fg="white")
        self.title_label.pack(pady=20)

        # Input fields
        self.input_frame = tk.Frame(root, bg="#667eea")
        self.input_frame.pack(pady=10)

        self.username_label = tk.Label(self.input_frame, text="Benutzername:", bg="#667eea", fg="white", font=("Arial", 12))
        self.username_label.grid(row=0, column=0, padx=5, pady=5)

        self.username_entry = tk.Entry(self.input_frame, font=("Arial", 12))
        self.username_entry.grid(row=0, column=1, padx=5, pady=5)

        self.password_label = tk.Label(self.input_frame, text="Passwort:", bg="#667eea", fg="white", font=("Arial", 12))
        self.password_label.grid(row=1, column=0, padx=5, pady=5)

        self.password_entry = tk.Entry(self.input_frame, show="*", font=("Arial", 12))
        self.password_entry.grid(row=1, column=1, padx=5, pady=5)

        self.add_button = tk.Button(self.input_frame, text="Eintrag hinzufügen", command=self.add_entry, bg="#28a745", fg="white", font=("Arial", 12))
        self.add_button.grid(row=2, column=0, columnspan=2, pady=10)

        # Instruction
        self.instruction_label = tk.Label(root, text="Achtung: Erst eintippen und dann \"Eintrag hinzufügen\" drücken für Download.", bg="#667eea", fg="white", font=("Arial", 10))
        self.instruction_label.pack(pady=10)

        # Entries list
        self.entries_frame = tk.Frame(root, bg="white", relief="sunken", bd=2)
        self.entries_frame.pack(pady=10, padx=20, fill="both", expand=True)

        self.entries_listbox = tk.Listbox(self.entries_frame, font=("Arial", 12), bg="#f8f9fa")
        self.entries_listbox.pack(fill="both", expand=True, padx=10, pady=10)

        # Buttons
        self.button_frame = tk.Frame(root, bg="#667eea")
        self.button_frame.pack(pady=20)

        self.download_button = tk.Button(self.button_frame, text="Passwörter herunterladen", command=self.download_passwords, bg="#667eea", fg="white", font=("Arial", 14))
        self.download_button.pack(side="left", padx=10)

        self.app_download_button = tk.Button(self.button_frame, text="App herunterladen", command=self.download_app, bg="#dc3545", fg="white", font=("Arial", 14))
        self.app_download_button.pack(side="right", padx=10)

    def add_entry(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        if not username or not password:
            messagebox.showerror("Error", "Bitte geben Sie sowohl Benutzername als auch Passwort ein.")
            return
        self.entries.append({"username": username, "password": password})
        self.update_display()
        self.username_entry.delete(0, tk.END)
        self.password_entry.delete(0, tk.END)

    def update_display(self):
        self.entries_listbox.delete(0, tk.END)
        for entry in self.entries:
            self.entries_listbox.insert(tk.END, f"Username: {entry['username']} | Password: {entry['password']}")

    def download_passwords(self):
        if not self.entries:
            messagebox.showerror("Error", "Bitte fügen Sie einige Einträge hinzu.")
            return

        content = """
╔══════════════════════════════════════════════╗
║                                              ║
║                 P A S S X                    ║
║                                              ║
║              Password Manager                ║
║                                              ║
╚══════════════════════════════════════════════╝

"""
        for i, entry in enumerate(self.entries, 1):
            content += f"""
┌──────────────────────────────────────────────┐
│ Entry {i}                                   │
├──────────────────────────────────────────────┤
│ Username: {entry['username'].ljust(30)} │
│ Password: {entry['password'].ljust(30)} │
└──────────────────────────────────────────────┘

"""
        content += """
╔══════════════════════════════════════════════╗
║                                              ║
║        . . .   . . .   . . .   . . .   .     .        ║
║        .   .   .     .   .   .   .   .   .   .        ║
║        . . .   . . . .   . . .   . . .   . . .        ║
║        .       .     .       .       .   .        ║
║        .       .     .       .       .     .        ║
║                                              ║
╚══════════════════════════════════════════════╝

P.a.s.s.X in all languages:
- English: P.a.s.s.X Watermark
- Deutsch: P.a.s.s.X Wasserzeichen
- Italiano: P.a.s.s.X Filigrana
- Français: P.a.s.s.X Filigrane
- Español: P.a.s.s.X Marca de Agua
- 中文: P.a.s.s.X 水印
- 日本語: P.a.s.s.X 透かし
- Русский: P.a.s.s.X Водяной Знак
- العربية: P.a.s.s.X علامة مائية
- Português: P.a.s.s.X Marca d'Água
- हिन्दी: P.a.s.s.X वॉटरमार्क
- 한국어: P.a.s.s.X 워터마크
- Nederlands: P.a.s.s.X Watermerk
- Svenska: P.a.s.s.X Vattenstämpel
- Dansk: P.a.s.s.X Vandmærk- Norsk: P.a.s.s.X Vannmerke
- Suomi: P.a.s.s.X Vesileima
- Polski: P.a.s.s.X Znak Wodny
- Türkçe: P.a.s.s.X Filigran
"""

        file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt")])
        if file_path:
            with open(file_path, "w") as file:
                file.write(content)
            messagebox.showinfo("Success", "Passwords downloaded successfully!")

    def download_app(self):
        # For simplicity, just show a message. In a real app, this would download the executable.
        messagebox.showinfo("Download", "App herunterladen - Funktion noch nicht implementiert. Bitte verwenden Sie die Webversion.")

if __name__ == "__main__":
    root = tk.Tk()
    app = PassXApp(root)
    root.mainloop()
